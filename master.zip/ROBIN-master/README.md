# ROBIN
ROBIN (Repository Of BuildIng plaNs)

## Publication Details

This paper was published in [ICDAR 2017](https://ieeexplore.ieee.org/abstract/document/8270007)

## Citation Details

### Plain Text
D. Sharma, N. Gupta, C. Chattopadhyay and S. Mehta, "DANIEL: A Deep Architecture for Automatic Analysis and Retrieval of Building Floor Plans," 2017 14th IAPR International Conference on Document Analysis and Recognition (ICDAR), 2017, pp. 420-425, doi: 10.1109/ICDAR.2017.76.

### BibTex
```
@INPROCEEDINGS{8270007,  
author={Sharma, Divya and Gupta, Nitin and Chattopadhyay, Chiranjoy and Mehta, Sameep},  
booktitle={2017 14th IAPR International Conference on Document Analysis and Recognition (ICDAR)},   
title={DANIEL: A Deep Architecture for Automatic Analysis and Retrieval of Building Floor Plans},   
year={2017},  
volume={01}, 
number={},  
pages={420-425},  
doi={10.1109/ICDAR.2017.76}}
```
